"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export default function AboutSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.25, 0.4, 0.25, 1],
      },
    },
  }

  const slideInLeft = {
    hidden: { opacity: 0, x: -100 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 1,
        ease: [0.25, 0.4, 0.25, 1],
      },
    },
  }

  const slideInRight = {
    hidden: { opacity: 0, x: 100 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        duration: 1,
        ease: [0.25, 0.4, 0.25, 1],
      },
    },
  }

  return (
    <section id="about" className="py-20 md:py-32 bg-[#030303] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/[0.05] via-transparent to-rose-500/[0.05] blur-3xl" />

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="max-w-4xl mx-auto"
        >
          <motion.div variants={itemVariants} className="text-center mb-16">
            <motion.h2
              className="text-3xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-white/80"
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.3 }}
            >
              About Me
            </motion.h2>
            <motion.div
              className="w-20 h-1 bg-gradient-to-r from-indigo-500 to-rose-500 mx-auto rounded-full"
              initial={{ width: 0 }}
              animate={isInView ? { width: 80 } : { width: 0 }}
              transition={{ duration: 1, delay: 0.5 }}
            />
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div variants={slideInLeft}>
              <motion.div className="relative" whileHover={{ scale: 1.02 }} transition={{ duration: 0.3 }}>
                <motion.div
                  className="w-full h-96 bg-gradient-to-br from-indigo-500/10 to-rose-500/10 rounded-2xl border border-white/10 flex items-center justify-center"
                  whileHover={{
                    borderColor: "rgba(255, 255, 255, 0.3)",
                    boxShadow: "0 20px 40px rgba(99, 102, 241, 0.1)",
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="text-white/40 text-center">
                    <motion.div
                      className="w-24 h-24 bg-white/5 rounded-full mx-auto mb-4 flex items-center justify-center"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <span className="text-2xl">👨‍💻</span>
                    </motion.div>
                    <p className="text-sm">Your photo here</p>
                  </div>
                </motion.div>
                <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500/20 to-rose-500/20 rounded-3xl blur-xl -z-10" />
              </motion.div>
            </motion.div>

            <motion.div variants={slideInRight} className="space-y-6">
              <motion.p
                className="text-lg text-white/70 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                whileHover={{ color: "rgba(255, 255, 255, 0.9)" }}
              >
                I'm a passionate developer with a love for creating beautiful, functional, and user-friendly digital
                experiences. With expertise in modern web technologies, I bring ideas to life through clean code and
                thoughtful design.
              </motion.p>

              <motion.p
                className="text-lg text-white/70 leading-relaxed"
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                whileHover={{ color: "rgba(255, 255, 255, 0.9)" }}
              >
                When I'm not coding, you can find me exploring new technologies, contributing to open-source projects,
                or sharing knowledge with the developer community.
              </motion.p>

              <motion.div
                className="grid grid-cols-2 gap-4 pt-6"
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.8, delay: 0.7 }}
              >
                <motion.div
                  className="p-4 bg-white/[0.02] border border-white/10 rounded-xl"
                  whileHover={{
                    scale: 1.05,
                    borderColor: "rgba(255, 255, 255, 0.2)",
                    backgroundColor: "rgba(255, 255, 255, 0.05)",
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <h4 className="text-white font-semibold mb-2">Experience</h4>
                  <p className="text-white/60 text-sm">5+ Years</p>
                </motion.div>
                <motion.div
                  className="p-4 bg-white/[0.02] border border-white/10 rounded-xl"
                  whileHover={{
                    scale: 1.05,
                    borderColor: "rgba(255, 255, 255, 0.2)",
                    backgroundColor: "rgba(255, 255, 255, 0.05)",
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <h4 className="text-white font-semibold mb-2">Projects</h4>
                  <p className="text-white/60 text-sm">50+ Completed</p>
                </motion.div>
              </motion.div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
