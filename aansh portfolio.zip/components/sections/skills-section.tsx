"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

const skillCategories = [
  {
    title: "Frontend",
    skills: [
      { name: "React", level: 95 },
      { name: "Next.js", level: 90 },
      { name: "TypeScript", level: 88 },
      { name: "Tailwind CSS", level: 92 },
      { name: "Framer Motion", level: 85 },
    ],
  },
  {
    title: "Backend",
    skills: [
      { name: "Node.js", level: 87 },
      { name: "Express.js", level: 85 },
      { name: "PostgreSQL", level: 80 },
      { name: "MongoDB", level: 82 },
      { name: "GraphQL", level: 75 },
    ],
  },
  {
    title: "Tools & Others",
    skills: [
      { name: "Git", level: 90 },
      { name: "Docker", level: 78 },
      { name: "AWS", level: 72 },
      { name: "Figma", level: 85 },
      { name: "Jest", level: 80 },
    ],
  },
]

function SkillBar({ skill, index }: { skill: { name: string; level: number }; index: number }) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -50 }}
      animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -50 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ x: 5 }}
      className="mb-6"
    >
      <div className="flex justify-between items-center mb-2">
        <motion.span
          className="text-white font-medium"
          whileHover={{ color: "rgba(99, 102, 241, 1)" }}
          transition={{ duration: 0.2 }}
        >
          {skill.name}
        </motion.span>
        <motion.span className="text-white/60 text-sm" whileHover={{ color: "rgba(255, 255, 255, 0.9)" }}>
          {skill.level}%
        </motion.span>
      </div>
      <motion.div
        className="w-full bg-white/10 rounded-full h-2"
        whileHover={{ backgroundColor: "rgba(255, 255, 255, 0.15)" }}
      >
        <motion.div
          initial={{ width: 0 }}
          animate={isInView ? { width: `${skill.level}%` } : { width: 0 }}
          transition={{ duration: 1.5, delay: index * 0.1 + 0.3, ease: "easeOut" }}
          className="h-2 bg-gradient-to-r from-indigo-500 to-rose-500 rounded-full"
          whileHover={{
            boxShadow: "0 0 20px rgba(99, 102, 241, 0.5)",
            scale: 1.02,
          }}
        />
      </motion.div>
    </motion.div>
  )
}

export default function SkillsSection() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })

  return (
    <section id="skills" className="py-20 md:py-32 bg-[#030303] relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-violet-500/[0.05] via-transparent to-amber-500/[0.05] blur-3xl" />

      <div className="container mx-auto px-4 md:px-6 relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <motion.h2
            className="text-3xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-white/80"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.3 }}
          >
            Skills & Expertise
          </motion.h2>
          <motion.div
            className="w-20 h-1 bg-gradient-to-r from-indigo-500 to-rose-500 mx-auto rounded-full mb-6"
            initial={{ width: 0 }}
            animate={isInView ? { width: 80 } : { width: 0 }}
            transition={{ duration: 1, delay: 0.3 }}
          />
          <motion.p
            className="text-lg text-white/60 max-w-2xl mx-auto"
            initial={{ opacity: 0, y: 20 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            whileHover={{ color: "rgba(255, 255, 255, 0.8)" }}
          >
            I'm constantly learning and improving my skills to stay current with the latest technologies and best
            practices.
          </motion.p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {skillCategories.map((category, categoryIndex) => (
            <motion.div
              key={category.title}
              initial={{ opacity: 0, y: 60, rotateY: 15 }}
              animate={isInView ? { opacity: 1, y: 0, rotateY: 0 } : { opacity: 0, y: 60, rotateY: 15 }}
              transition={{
                duration: 0.8,
                delay: categoryIndex * 0.2,
                ease: [0.25, 0.4, 0.25, 1],
              }}
              whileHover={{
                y: -10,
                scale: 1.02,
                rotateY: -2,
                transition: { duration: 0.3 },
              }}
              className="bg-white/[0.02] border border-white/10 rounded-2xl p-6 group"
            >
              <motion.h3
                className="text-xl font-bold text-white mb-6 text-center"
                whileHover={{
                  color: "rgba(99, 102, 241, 1)",
                  scale: 1.05,
                }}
                transition={{ duration: 0.2 }}
              >
                {category.title}
              </motion.h3>
              <div>
                {category.skills.map((skill, skillIndex) => (
                  <SkillBar key={skill.name} skill={skill} index={skillIndex} />
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
